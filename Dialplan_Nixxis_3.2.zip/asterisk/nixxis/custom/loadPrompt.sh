#!/bin/sh

if [ -z "$1" ] ; then
  exit 1
fi

curl -s http://10.67.0.25/DynParam/ivr/prompt/$1?language=$2 | jq -r '("prompt_file=" + .FileName)'
