#!/bin/sh
if [ -z "$1" ] ; then
  exit 1
fi
#echo $1 > /tmp/lastContactId
ZipCode="ZipCode="
curl=$(curl -s --connect-timeout 5 "http://10.67.0.25:8088/data/?action=GetContextData&contact=$1" -H "Accept: application/xml")
ZipCode+=$(xmlstarlet sel --template --value-of /contextdata/campaigndata/_PostalCode --nl <<< $curl)

echo "$ZipCode"
