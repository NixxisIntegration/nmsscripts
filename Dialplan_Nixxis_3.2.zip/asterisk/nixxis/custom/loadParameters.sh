#!/bin/sh
if [ -z "$1" ] ; then
  exit 1
fi
#echo $1 > /tmp/lastContactId

curl -s http://10.67.0.25/DynParam/ivr/contact/$1/parameters/$2 | jq -r 'del(.Messages)|keys[] as $k|"\($k)=\(.[$k])"'
