#!/usr/local/bin/kermit +

# Version("2.1.0.0")
# InformationalVersion("2.1.0.0")

#
# Please download, compile and install
# ftp://kermit.columbia.edu/kermit/archives/cku211.tar.gz
#
 
set file stringspace 10000000
set file listsize 1000000
ftp open 192.168.101.2 /user:recording /password:recording
if fail exit 1 Connection failed
if not \v(ftp_loggedin) exit 1 Login failed
ftp cd /
if fail exit 1 ftp cd working: \v(ftp_message)
lcd /home/recording
if fail exit 1 lcd /home/recording: \v(errstring)
ftp put /before:-21days /delete *
if fail exit 1 ftp put /before:-21days /delete *: \v(ftp_message)
quit