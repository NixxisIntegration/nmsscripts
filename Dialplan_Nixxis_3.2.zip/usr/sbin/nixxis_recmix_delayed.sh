#!/bin/sh
# Version("2.1.0.1")
# InformationalVersion("2.1.0.0")

cd /home/recording

timedif=3

#echo find /home/recording/*-in.wav -type f -mmin +$timedif

#echo `date` >>/var/log/recmix.log

#echo `date '+%b %d %H:%M:%S'` Starting recmix...>>/var/log/recmix.log


# Locate files that haven't changed in $timedif minutes.
for f in `nice -n 19 find /home/recording/*-in.wav -type f -cmin +$timedif`

do

    # Create full path filename without the leading -in or -out.
    var=`echo $f|awk -F"-in" '{ print $1}'`

    #echo Processing $var ...
    #echo `date '+%b %d %H:%M:%S'` Processing $var >>/var/log/recmix.log

    # Now mix the two files into 1 main file
    nice -n 19 sox -m $var"-in.wav" $var"-out.wav" $var".wav"

    # Delete the in and out
    rm $var"-in.wav"
    rm $var"-out.wav"

    # Move the in and out
    # nice -n 19 nice -n 19 mv $var"-in.wav" splits/
    # nice -n 19 nice -n 19 mv $var"-out.wav" splits/
done